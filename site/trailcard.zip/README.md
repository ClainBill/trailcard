# Trailcard

A Chrome extension that turns what you just looked up into spaced-repetition flashcards. It keeps a short local trail of your searches and page visits, and when you click **Create Flashcard** it asks Claude what you were trying to remember and drafts a multi-field card for you to review and edit. Each review quizzes the card from a random direction.

## Install (unpacked)

1. Open `chrome://extensions` and turn on **Developer mode**.
2. Click **Load unpacked** and choose this folder.
3. Click the Trailcard toolbar icon (or press Alt+Shift+F) to open the side panel.
4. Open **Settings** and paste a Claude API key. Without one you still get a basic card built from the page alone.

## How it works

- `background.js` records searches, page visits, link text you clicked, text you copied and time on page. The trail stays in `chrome.storage.local`, is capped at 24 hours, and skips sites on the blocklist.
- `panel.js` is the side panel. Create Flashcard reads the current page (`lib/extract.js`), combines it with the trail and sends both to Claude (`lib/ai.js`), then opens the editor (`lib/editor.js`).
- `app.js` is the full-page app: daily review, card library and settings.
- `lib/fsrs.js` is an FSRS-4.5 scheduler. `lib/cards.js` holds the card model and the random question picker.

## Development

- `npm test` runs the unit tests (scheduler, card model, trail parsing).
- `npm run preview` serves the pages at http://localhost:4173. Outside the extension, `panel.html` and `app.html` run in demo mode with a sample trail and `localStorage`.
